<?php
require_once '../../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$requiredFields = ['product_id'];
$missingFields = validateRequiredFields($data, $requiredFields);

if (!empty($missingFields)) {
    jsonResponse(['error' => 'Missing required fields', 'fields' => $missingFields], 400);
}

try {
    $db = getDbConnection();
    
    // Get product and store details
    $stmt = $db->prepare('
        SELECT 
            p.id, p.name, p.price,
            s.id as store_id, s.name as store_name,
            b.business_name, b.contact_phone, b.contact_email
        FROM 
            products p
        JOIN 
            stores s ON p.store_id = s.id
        JOIN 
            businesses b ON s.business_id = b.id
        WHERE 
            p.id = :product_id
    ');
    
    $stmt->bindValue(':product_id', $data['product_id'], SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    $product = $result->fetchArray(SQLITE3_ASSOC);
    
    if (!$product) {
        jsonResponse(['error' => 'Product not found'], 404);
    }
    
    // Generate WhatsApp message template
    $message = "Hi! I'm interested in {$product['name']} from your {$product['store_name']} store. Price: {$product['price']}. Is this available?";
    
    // Generate WhatsApp URL
    $whatsappUrl = null;
    if ($product['contact_phone']) {
        $phone = preg_replace('/[^0-9]/', '', $product['contact_phone']);
        $whatsappUrl = "https://wa.me/{$phone}?text=" . urlencode($message);
    }
    
    // Track WhatsApp click for analytics
    $userId = getCurrentUserId();
    if ($userId) {
        $analyticsStmt = $db->prepare('
            INSERT INTO analytics_events (event_type, store_id, product_id, user_id, ip_address, user_agent)
            VALUES (:event_type, :store_id, :product_id, :user_id, :ip_address, :user_agent)
        ');
        
        $analyticsStmt->bindValue(':event_type', 'whatsapp_click', SQLITE3_TEXT);
        $analyticsStmt->bindValue(':store_id', $product['store_id'], SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':product_id', $product['id'], SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':user_id', $userId, SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':ip_address', $_SERVER['REMOTE_ADDR'], SQLITE3_TEXT);
        $analyticsStmt->bindValue(':user_agent', $_SERVER['HTTP_USER_AGENT'], SQLITE3_TEXT);
        
        $analyticsStmt->execute();
    }
    
    jsonResponse([
        'success' => true,
        'whatsapp_url' => $whatsappUrl,
        'message_template' => $message,
        'contact_phone' => $product['contact_phone'],
        'contact_email' => $product['contact_email']
    ]);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to generate contact info', 'message' => $e->getMessage()], 500);
}
