<?php
require_once '../../config.php';

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Get query parameters
$search = isset($_GET['search']) ? $_GET['search'] : null;
$category = isset($_GET['category']) ? $_GET['category'] : null;
$latitude = isset($_GET['lat']) ? (float)$_GET['lat'] : null;
$longitude = isset($_GET['lng']) ? (float)$_GET['lng'] : null;
$distance = isset($_GET['distance']) ? (int)$_GET['distance'] : 10; // Default 10km
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;

try {
    $db = getDbConnection();
    
    // Build query conditions
    $conditions = ['s.is_open = 1']; // Only show open stores
    $params = [];
    
    if ($search) {
        $conditions[] = "(s.name LIKE :search OR s.description LIKE :search)";
        $params[':search'] = ['%' . $search . '%', SQLITE3_TEXT];
    }
    
    if ($category) {
        $conditions[] = "EXISTS (
            SELECT 1 FROM products p
            JOIN categories c ON p.category_id = c.id
            WHERE p.store_id = s.id AND c.name = :category
        )";
        $params[':category'] = [$category, SQLITE3_TEXT];
    }
    
    // Location-based search
    $locationJoin = '';
    if ($latitude && $longitude) {
        // SQLite doesn't have built-in geospatial functions, so we use the Haversine formula
        // This is a simplified version and not as accurate for very long distances
        $locationJoin = "
            , (
                6371 * acos(
                    cos(radians(:latitude)) * 
                    cos(radians(s.latitude)) * 
                    cos(radians(s.longitude) - radians(:longitude)) + 
                    sin(radians(:latitude)) * 
                    sin(radians(s.latitude))
                )
            ) AS distance
        ";
        
        $conditions[] = "s.latitude IS NOT NULL AND s.longitude IS NOT NULL";
        $conditions[] = "distance <= :distance";
        
        $params[':latitude'] = [$latitude, SQLITE3_FLOAT];
        $params[':longitude'] = [$longitude, SQLITE3_FLOAT];
        $params[':distance'] = [$distance, SQLITE3_FLOAT];
    }
    
    // Build the WHERE clause
    $whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';
    
    // Build the ORDER BY clause
    $orderBy = $latitude && $longitude ? 'ORDER BY distance ASC' : 'ORDER BY s.name ASC';
    
    // Build the final query
    $query = "
        SELECT 
            s.id, s.name, s.slug, s.description, s.logo, s.banner,
            s.location, s.latitude, s.longitude,
            b.business_name,
            (SELECT COUNT(*) FROM reviews r WHERE r.store_id = s.id) AS review_count,
            (SELECT AVG(rating) FROM reviews r WHERE r.store_id = s.id) AS avg_rating
            $locationJoin
        FROM 
            stores s
        JOIN 
            businesses b ON s.business_id = b.id
        $whereClause
        $orderBy
        LIMIT :limit OFFSET :offset
    ";
    
    $stmt = $db->prepare($query);
    
    // Bind parameters
    foreach ($params as $param => $value) {
        $stmt->bindValue($param, $value[0], $value[1]);
    }
    
    $stmt->bindValue(':limit', $limit, SQLITE3_INTEGER);
    $stmt->bindValue(':offset', $offset, SQLITE3_INTEGER);
    
    $result = $stmt->execute();
    
    $stores = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        // Track store view for analytics
        $userId = getCurrentUserId();
        if ($userId) {
            $analyticsStmt = $db->prepare('
                INSERT INTO analytics_events (event_type, store_id, user_id, ip_address, user_agent)
                VALUES (:event_type, :store_id, :user_id, :ip_address, :user_agent)
            ');
            
            $analyticsStmt->bindValue(':event_type', 'store_view', SQLITE3_TEXT);
            $analyticsStmt->bindValue(':store_id', $row['id'], SQLITE3_INTEGER);
            $analyticsStmt->bindValue(':user_id', $userId, SQLITE3_INTEGER);
            $analyticsStmt->bindValue(':ip_address', $_SERVER['REMOTE_ADDR'], SQLITE3_TEXT);
            $analyticsStmt->bindValue(':user_agent', $_SERVER['HTTP_USER_AGENT'], SQLITE3_TEXT);
            
            $analyticsStmt->execute();
        }
        
        $stores[] = $row;
    }
    
    // Get total count for pagination
    $countQuery = "
        SELECT COUNT(*) as total
        FROM stores s
        JOIN businesses b ON s.business_id = b.id
        $whereClause
    ";
    
    $countStmt = $db->prepare($countQuery);
    
    // Bind parameters for count query
    foreach ($params as $param => $value) {
        $countStmt->bindValue($param, $value[0], $value[1]);
    }
    
    $countResult = $countStmt->execute();
    $totalCount = $countResult->fetchArray(SQLITE3_ASSOC)['total'];
    
    jsonResponse([
        'success' => true,
        'stores' => $stores,
        'total' => $totalCount,
        'limit' => $limit,
        'offset' => $offset
    ]);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to get stores', 'message' => $e->getMessage()], 500);
}
