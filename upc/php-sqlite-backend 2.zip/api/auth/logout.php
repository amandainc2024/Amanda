<?php
require_once '../../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Start session
session_start();

// Destroy session
session_destroy();

jsonResponse([
    'success' => true,
    'message' => 'Logout successful'
]);
