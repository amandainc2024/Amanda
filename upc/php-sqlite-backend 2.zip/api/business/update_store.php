<?php
require_once '../../config.php';

// Only allow PUT requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Check if user is authenticated and is a business
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'business') {
    jsonResponse(['error' => 'Unauthorized'], 401);
}

// Get form data
$data = $_POST;

// Validate required fields
$requiredFields = ['store_id'];
$missingFields = validateRequiredFields($data, $requiredFields);

if (!empty($missingFields)) {
    jsonResponse(['error' => 'Missing required fields', 'fields' => $missingFields], 400);
}

try {
    $db = getDbConnection();
    
    // Check if store belongs to the business
    $stmt = $db->prepare('
        SELECT s.id FROM stores s
        JOIN businesses b ON s.business_id = b.id
        WHERE s.id = :store_id AND b.user_id = :user_id
    ');
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if (!$result->fetchArray()) {
        jsonResponse(['error' => 'Store not found or access denied'], 403);
    }
    
    // Handle logo upload
    $logoFilename = null;
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $logoFilename = handleFileUpload($_FILES['logo'], STORE_IMAGES_DIR);
    }
    
    // Handle banner upload
    $bannerFilename = null;
    if (isset($_FILES['banner']) && $_FILES['banner']['error'] === UPLOAD_ERR_OK) {
        $bannerFilename = handleFileUpload($_FILES['banner'], STORE_IMAGES_DIR);
    }
    
    // Build update query dynamically based on provided fields
    $updateFields = [];
    $params = [];
    
    // Text fields
    $textFields = ['name', 'description', 'theme', 'contact_info', 'location'];
    foreach ($textFields as $field) {
        if (isset($data[$field])) {
            $updateFields[] = "$field = :$field";
            $params[":$field"] = [$data[$field], SQLITE3_TEXT];
        }
    }
    
    // Numeric fields
    $numericFields = ['is_open', 'latitude', 'longitude'];
    foreach ($numericFields as $field) {
        if (isset($data[$field])) {
            $updateFields[] = "$field = :$field";
            $params[":$field"] = [$data[$field], $field === 'is_open' ? SQLITE3_INTEGER : SQLITE3_FLOAT];
        }
    }
    
    // File fields
    if ($logoFilename) {
        $updateFields[] = "logo = :logo";
        $params[':logo'] = [$logoFilename, SQLITE3_TEXT];
    }
    
    if ($bannerFilename) {
        $updateFields[] = "banner = :banner";
        $params[':banner'] = [$bannerFilename, SQLITE3_TEXT];
    }
    
    // Add updated_at timestamp
    $updateFields[] = "updated_at = CURRENT_TIMESTAMP";
    
    // If no fields to update, return success
    if (empty($updateFields)) {
        jsonResponse([
            'success' => true,
            'message' => 'No fields to update'
        ]);
    }
    
    // Build and execute update query
    $query = "UPDATE stores SET " . implode(', ', $updateFields) . " WHERE id = :store_id";
    $stmt = $db->prepare($query);
    
    // Bind parameters
    foreach ($params as $param => $value) {
        $stmt->bindValue($param, $value[0], $value[1]);
    }
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->execute();
    
    jsonResponse([
        'success' => true,
        'message' => 'Store updated successfully'
    ]);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to update store', 'message' => $e->getMessage()], 500);
}
