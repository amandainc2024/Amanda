<?php
require_once '../../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Check if user is authenticated
session_start();
if (!isset($_SESSION['user_id'])) {
    jsonResponse(['error' => 'Unauthorized'], 401);
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$requiredFields = ['store_id', 'rating'];
$missingFields = validateRequiredFields($data, $requiredFields);

if (!empty($missingFields)) {
    jsonResponse(['error' => 'Missing required fields', 'fields' => $missingFields], 400);
}

// Validate rating
if ($data['rating'] < 1 || $data['rating'] > 5) {
    jsonResponse(['error' => 'Rating must be between 1 and 5'], 400);
}

try {
    $db = getDbConnection();
    
    // Check if store exists
    $stmt = $db->prepare('SELECT id FROM stores WHERE id = :store_id');
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if (!$result->fetchArray()) {
        jsonResponse(['error' => 'Store not found'], 404);
    }
    
    // Check if user has already reviewed this store
    $stmt = $db->prepare('
        SELECT id FROM reviews 
        WHERE store_id = :store_id AND user_id = :user_id
    ');
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if ($result->fetchArray()) {
        jsonResponse(['error' => 'You have already reviewed this store'], 409);
    }
    
    // Insert review
    $stmt = $db->prepare('
        INSERT INTO reviews (store_id, user_id, rating, comment)
        VALUES (:store_id, :user_id, :rating, :comment)
    ');
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':rating', $data['rating'], SQLITE3_INTEGER);
    $stmt->bindValue(':comment', $data['comment'] ?? '', SQLITE3_TEXT);
    
    $stmt->execute();
    $reviewId = $db->lastInsertRowID();
    
    jsonResponse([
        'success' => true,
        'message' => 'Review added successfully',
        'review_id' => $reviewId
    ], 201);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to add review', 'message' => $e->getMessage()], 500);
}
