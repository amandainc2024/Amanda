<?php
require_once '../../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$requiredFields = ['email', 'password'];
$missingFields = validateRequiredFields($data, $requiredFields);

if (!empty($missingFields)) {
    jsonResponse(['error' => 'Missing required fields', 'fields' => $missingFields], 400);
}

try {
    $db = getDbConnection();
    
    // Find user by email
    $stmt = $db->prepare('SELECT id, name, email, password, user_type FROM users WHERE email = :email');
    $stmt->bindValue(':email', $data['email'], SQLITE3_TEXT);
    $result = $stmt->execute();
    
    $user = $result->fetchArray(SQLITE3_ASSOC);
    
    if (!$user) {
        jsonResponse(['error' => 'Invalid email or password'], 401);
    }
    
    // Verify password
    if (!password_verify($data['password'], $user['password'])) {
        jsonResponse(['error' => 'Invalid email or password'], 401);
    }
    
    // Start session and store user data
    session_start();
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_type'] = $user['user_type'];
    $_SESSION['name'] = $user['name'];
    
    // Get business ID if user is a business
    $businessId = null;
    if ($user['user_type'] === 'business') {
        $stmt = $db->prepare('SELECT id FROM businesses WHERE user_id = :user_id');
        $stmt->bindValue(':user_id', $user['id'], SQLITE3_INTEGER);
        $result = $stmt->execute();
        
        $business = $result->fetchArray(SQLITE3_ASSOC);
        if ($business) {
            $businessId = $business['id'];
            $_SESSION['business_id'] = $businessId;
        }
    }
    
    // Remove password from response
    unset($user['password']);
    
    jsonResponse([
        'success' => true,
        'message' => 'Login successful',
        'user' => $user,
        'business_id' => $businessId
    ]);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Login failed', 'message' => $e->getMessage()], 500);
}
