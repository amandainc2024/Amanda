<?php
// Database configuration
define('DB_PATH', __DIR__ . '/database/shopbeta.db');
define('UPLOADS_DIR', __DIR__ . '/uploads');
define('STORE_IMAGES_DIR', UPLOADS_DIR . '/stores');
define('PRODUCT_IMAGES_DIR', UPLOADS_DIR . '/products');
define('QR_CODES_DIR', UPLOADS_DIR . '/qrcodes');

// Ensure upload directories exist
if (!file_exists(UPLOADS_DIR)) mkdir(UPLOADS_DIR, 0755, true);
if (!file_exists(STORE_IMAGES_DIR)) mkdir(STORE_IMAGES_DIR, 0755, true);
if (!file_exists(PRODUCT_IMAGES_DIR)) mkdir(PRODUCT_IMAGES_DIR, 0755, true);
if (!file_exists(QR_CODES_DIR)) mkdir(QR_CODES_DIR, 0755, true);

// Initialize database connection
function getDbConnection() {
    $db = new SQLite3(DB_PATH);
    $db->enableExceptions(true);
    return $db;
}

// Helper function for API responses
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Helper function to validate required fields
function validateRequiredFields($data, $requiredFields) {
    $missingFields = [];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            $missingFields[] = $field;
        }
    }
    return $missingFields;
}

// Generate a unique slug
function generateSlug($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    
    if (empty($text)) {
        return 'n-a-' . uniqid();
    }
    
    return $text . '-' . substr(uniqid(), -5);
}

// Generate QR code (placeholder - you'll need a QR library)
function generateQRCode($data, $filename) {
    // In a real implementation, you would use a library like phpqrcode
    // For now, we'll just create a placeholder file
    file_put_contents(QR_CODES_DIR . '/' . $filename, "QR Code data: " . $data);
    return $filename;
}

// Handle file uploads
function handleFileUpload($file, $destination) {
    $filename = uniqid() . '-' . basename($file['name']);
    $targetPath = $destination . '/' . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return $filename;
    }
    
    return false;
}

// Get current authenticated user ID (from session)
function getCurrentUserId() {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    return $_SESSION['user_id'];
}
