<?php
require_once '../../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Check if user is authenticated and is a business
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'business') {
    jsonResponse(['error' => 'Unauthorized'], 401);
}

// Get form data
$data = $_POST;

// Validate required fields
$requiredFields = ['store_id', 'content'];
$missingFields = validateRequiredFields($data, $requiredFields);

if (!empty($missingFields)) {
    jsonResponse(['error' => 'Missing required fields', 'fields' => $missingFields], 400);
}

try {
    $db = getDbConnection();
    
    // Check if store belongs to the business
    $stmt = $db->prepare('
        SELECT s.id FROM stores s
        JOIN businesses b ON s.business_id = b.id
        WHERE s.id = :store_id AND b.user_id = :user_id
    ');
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if (!$result->fetchArray()) {
        jsonResponse(['error' => 'Store not found or access denied'], 403);
    }
    
    // Handle status image upload
    $imageFilename = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $imageFilename = handleFileUpload($_FILES['image'], UPLOADS_DIR . '/statuses');
    }
    
    // Calculate expiry time (default 24 hours)
    $expiresAt = date('Y-m-d H:i:s', strtotime('+24 hours'));
    if (isset($data['expires_hours']) && is_numeric($data['expires_hours'])) {
        $expiresAt = date('Y-m-d H:i:s', strtotime('+' . $data['expires_hours'] . ' hours'));
    }
    
    // Insert status
    $stmt = $db->prepare('
        INSERT INTO store_statuses (store_id, content, image, expires_at)
        VALUES (:store_id, :content, :image, :expires_at)
    ');
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':content', $data['content'], SQLITE3_TEXT);
    $stmt->bindValue(':image', $imageFilename, SQLITE3_TEXT);
    $stmt->bindValue(':expires_at', $expiresAt, SQLITE3_TEXT);
    
    $stmt->execute();
    $statusId = $db->lastInsertRowID();
    
    jsonResponse([
        'success' => true,
        'message' => 'Status posted successfully',
        'status_id' => $statusId,
        'expires_at' => $expiresAt
    ], 201);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to post status', 'message' => $e->getMessage()], 500);
}
