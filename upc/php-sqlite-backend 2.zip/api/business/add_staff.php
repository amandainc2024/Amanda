<?php
require_once '../../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Check if user is authenticated and is a business
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'business') {
    jsonResponse(['error' => 'Unauthorized'], 401);
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$requiredFields = ['store_id', 'email', 'role'];
$missingFields = validateRequiredFields($data, $requiredFields);

if (!empty($missingFields)) {
    jsonResponse(['error' => 'Missing required fields', 'fields' => $missingFields], 400);
}

// Validate role
if (!in_array($data['role'], ['manager', 'staff'])) {
    jsonResponse(['error' => 'Invalid role. Must be "manager" or "staff"'], 400);
}

try {
    $db = getDbConnection();
    
    // Check if store belongs to the business
    $stmt = $db->prepare('
        SELECT s.id FROM stores s
        JOIN businesses b ON s.business_id = b.id
        WHERE s.id = :store_id AND b.user_id = :user_id
    ');
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if (!$result->fetchArray()) {
        jsonResponse(['error' => 'Store not found or access denied'], 403);
    }
    
    // Find user by email
    $stmt = $db->prepare('SELECT id FROM users WHERE email = :email');
    $stmt->bindValue(':email', $data['email'], SQLITE3_TEXT);
    $result = $stmt->execute();
    
    $user = $result->fetchArray(SQLITE3_ASSOC);
    
    if (!$user) {
        jsonResponse(['error' => 'User not found'], 404);
    }
    
    // Check if user is already a staff member
    $stmt = $db->prepare('
        SELECT id FROM store_staff 
        WHERE store_id = :store_id AND user_id = :user_id
    ');
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':user_id', $user['id'], SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if ($result->fetchArray()) {
        jsonResponse(['error' => 'User is already a staff member'], 409);
    }
    
    // Add staff member
    $stmt = $db->prepare('
        INSERT INTO store_staff (store_id, user_id, role)
        VALUES (:store_id, :user_id, :role)
    ');
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':user_id', $user['id'], SQLITE3_INTEGER);
    $stmt->bindValue(':role', $data['role'], SQLITE3_TEXT);
    
    $stmt->execute();
    
    jsonResponse([
        'success' => true,
        'message' => 'Staff member added successfully'
    ], 201);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to add staff member', 'message' => $e->getMessage()], 500);
}
