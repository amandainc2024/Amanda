<?php
// Setup script to initialize the database and create sample data

require_once 'config.php';
require_once 'init_db.php';

try {
    $db = getDbConnection();
    
    // Insert sample categories
    $categories = [
        'Electronics',
        'Clothing',
        'Food & Beverages',
        'Home & Garden',
        'Health & Beauty',
        'Sports & Outdoors',
        'Books & Media',
        'Automotive'
    ];
    
    foreach ($categories as $category) {
        $stmt = $db->prepare('INSERT OR IGNORE INTO categories (name) VALUES (:name)');
        $stmt->bindValue(':name', $category, SQLITE3_TEXT);
        $stmt->execute();
    }
    
    echo "Setup completed successfully!\n";
    echo "Database initialized with sample categories.\n";
    echo "You can now start using the API endpoints.\n";
    
} catch (Exception $e) {
    echo "Setup failed: " . $e->getMessage() . "\n";
}
