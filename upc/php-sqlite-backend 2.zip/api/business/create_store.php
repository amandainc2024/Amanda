<?php
require_once '../../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Check if user is authenticated and is a business
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'business') {
    jsonResponse(['error' => 'Unauthorized'], 401);
}

// Get form data (multipart/form-data for file uploads)
$data = $_POST;

// Validate required fields
$requiredFields = ['name', 'description'];
$missingFields = validateRequiredFields($data, $requiredFields);

if (!empty($missingFields)) {
    jsonResponse(['error' => 'Missing required fields', 'fields' => $missingFields], 400);
}

try {
    $db = getDbConnection();
    
    // Get business ID
    $businessId = $_SESSION['business_id'];
    if (!$businessId) {
        $stmt = $db->prepare('SELECT id FROM businesses WHERE user_id = :user_id');
        $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
        $result = $stmt->execute();
        
        $business = $result->fetchArray(SQLITE3_ASSOC);
        if (!$business) {
            jsonResponse(['error' => 'Business not found'], 404);
        }
        
        $businessId = $business['id'];
        $_SESSION['business_id'] = $businessId;
    }
    
    // Generate slug from store name
    $slug = generateSlug($data['name']);
    
    // Handle logo upload
    $logoFilename = null;
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $logoFilename = handleFileUpload($_FILES['logo'], STORE_IMAGES_DIR);
        if (!$logoFilename) {
            jsonResponse(['error' => 'Failed to upload logo'], 500);
        }
    }
    
    // Handle banner upload
    $bannerFilename = null;
    if (isset($_FILES['banner']) && $_FILES['banner']['error'] === UPLOAD_ERR_OK) {
        $bannerFilename = handleFileUpload($_FILES['banner'], STORE_IMAGES_DIR);
        if (!$bannerFilename) {
            jsonResponse(['error' => 'Failed to upload banner'], 500);
        }
    }
    
    // Insert store
    $stmt = $db->prepare('
        INSERT INTO stores (
            business_id, name, slug, description, theme, logo, banner, 
            contact_info, location, latitude, longitude, is_open
        )
        VALUES (
            :business_id, :name, :slug, :description, :theme, :logo, :banner, 
            :contact_info, :location, :latitude, :longitude, :is_open
        )
    ');
    
    $stmt->bindValue(':business_id', $businessId, SQLITE3_INTEGER);
    $stmt->bindValue(':name', $data['name'], SQLITE3_TEXT);
    $stmt->bindValue(':slug', $slug, SQLITE3_TEXT);
    $stmt->bindValue(':description', $data['description'], SQLITE3_TEXT);
    $stmt->bindValue(':theme', $data['theme'] ?? 'default', SQLITE3_TEXT);
    $stmt->bindValue(':logo', $logoFilename, SQLITE3_TEXT);
    $stmt->bindValue(':banner', $bannerFilename, SQLITE3_TEXT);
    $stmt->bindValue(':contact_info', $data['contact_info'] ?? '', SQLITE3_TEXT);
    $stmt->bindValue(':location', $data['location'] ?? '', SQLITE3_TEXT);
    $stmt->bindValue(':latitude', $data['latitude'] ?? null, SQLITE3_FLOAT);
    $stmt->bindValue(':longitude', $data['longitude'] ?? null, SQLITE3_FLOAT);
    $stmt->bindValue(':is_open', $data['is_open'] ?? 1, SQLITE3_INTEGER);
    
    $stmt->execute();
    $storeId = $db->lastInsertRowID();
    
    // Add owner as staff
    $stmt = $db->prepare('
        INSERT INTO store_staff (store_id, user_id, role)
        VALUES (:store_id, :user_id, :role)
    ');
    
    $stmt->bindValue(':store_id', $storeId, SQLITE3_INTEGER);
    $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':role', 'owner', SQLITE3_TEXT);
    
    $stmt->execute();
    
    // Generate QR code for store
    $qrData = json_encode(['type' => 'store', 'id' => $storeId, 'slug' => $slug]);
    $qrFilename = 'store-' . $storeId . '.png';
    generateQRCode($qrData, $qrFilename);
    
    jsonResponse([
        'success' => true,
        'message' => 'Store created successfully',
        'store_id' => $storeId,
        'slug' => $slug,
        'qr_code' => $qrFilename
    ], 201);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to create store', 'message' => $e->getMessage()], 500);
}
