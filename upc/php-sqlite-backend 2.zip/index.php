<?php
require_once 'config.php';

// Simple router
$requestUri = $_SERVER['REQUEST_URI'];
$requestMethod = $_SERVER['REQUEST_METHOD'];

// Remove query string from URI
$uri = parse_url($requestUri, PHP_URL_PATH);

// Define routes
$routes = [
    // Auth routes
    'POST /api/auth/register' => 'api/auth/register.php',
    'POST /api/auth/login' => 'api/auth/login.php',
    'POST /api/auth/logout' => 'api/auth/logout.php',
    
    // Business routes
    'POST /api/business/create-store' => 'api/business/create_store.php',
    'POST /api/business/add-product' => 'api/business/add_product.php',
    'POST /api/business/update-store' => 'api/business/update_store.php',
    'POST /api/business/add-staff' => 'api/business/add_staff.php',
    'POST /api/business/post-status' => 'api/business/post_status.php',
    'GET /api/business/analytics' => 'api/business/analytics.php',
    
    // Buyer routes
    'GET /api/buyer/stores' => 'api/buyer/stores.php',
    'GET /api/buyer/store-details' => 'api/buyer/store_details.php',
    'GET /api/buyer/products' => 'api/buyer/products.php',
    'GET /api/buyer/product-details' => 'api/buyer/product_details.php',
    'POST /api/buyer/contact-seller' => 'api/buyer/contact_seller.php',
    'POST /api/buyer/add-review' => 'api/buyer/add_review.php',
    
    // QR routes
    'POST /api/qr/scan' => 'api/qr/scan.php',
];

// Find matching route
$routeKey = $requestMethod . ' ' . $uri;

if (isset($routes[$routeKey])) {
    require_once $routes[$routeKey];
} else {
    // Default response for unknown routes
    jsonResponse(['error' => 'Route not found'], 404);
}
