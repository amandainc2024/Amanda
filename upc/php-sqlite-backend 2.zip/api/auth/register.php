<?php
require_once '../../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$requiredFields = ['name', 'email', 'phone', 'password', 'user_type'];
$missingFields = validateRequiredFields($data, $requiredFields);

if (!empty($missingFields)) {
    jsonResponse(['error' => 'Missing required fields', 'fields' => $missingFields], 400);
}

// Validate user type
if (!in_array($data['user_type'], ['business', 'buyer'])) {
    jsonResponse(['error' => 'Invalid user type. Must be "business" or "buyer"'], 400);
}

try {
    $db = getDbConnection();
    
    // Check if email already exists
    $stmt = $db->prepare('SELECT id FROM users WHERE email = :email');
    $stmt->bindValue(':email', $data['email'], SQLITE3_TEXT);
    $result = $stmt->execute();
    
    if ($result->fetchArray()) {
        jsonResponse(['error' => 'Email already registered'], 409);
    }
    
    // Check if phone already exists
    $stmt = $db->prepare('SELECT id FROM users WHERE phone = :phone');
    $stmt->bindValue(':phone', $data['phone'], SQLITE3_TEXT);
    $result = $stmt->execute();
    
    if ($result->fetchArray()) {
        jsonResponse(['error' => 'Phone number already registered'], 409);
    }
    
    // Hash password
    $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
    
    // Insert user
    $stmt = $db->prepare('
        INSERT INTO users (name, email, phone, password, user_type)
        VALUES (:name, :email, :phone, :password, :user_type)
    ');
    
    $stmt->bindValue(':name', $data['name'], SQLITE3_TEXT);
    $stmt->bindValue(':email', $data['email'], SQLITE3_TEXT);
    $stmt->bindValue(':phone', $data['phone'], SQLITE3_TEXT);
    $stmt->bindValue(':password', $hashedPassword, SQLITE3_TEXT);
    $stmt->bindValue(':user_type', $data['user_type'], SQLITE3_TEXT);
    
    $stmt->execute();
    $userId = $db->lastInsertRowID();
    
    // If user is a business, create business record
    if ($data['user_type'] === 'business' && isset($data['business_name'])) {
        $stmt = $db->prepare('
            INSERT INTO businesses (user_id, business_name, business_type, description, location)
            VALUES (:user_id, :business_name, :business_type, :description, :location)
        ');
        
        $stmt->bindValue(':user_id', $userId, SQLITE3_INTEGER);
        $stmt->bindValue(':business_name', $data['business_name'], SQLITE3_TEXT);
        $stmt->bindValue(':business_type', $data['business_type'] ?? 'Other', SQLITE3_TEXT);
        $stmt->bindValue(':description', $data['description'] ?? '', SQLITE3_TEXT);
        $stmt->bindValue(':location', $data['location'] ?? '', SQLITE3_TEXT);
        
        $stmt->execute();
        $businessId = $db->lastInsertRowID();
        
        jsonResponse([
            'success' => true,
            'message' => 'Business registered successfully',
            'user_id' => $userId,
            'business_id' => $businessId
        ], 201);
    }
    
    jsonResponse([
        'success' => true,
        'message' => 'User registered successfully',
        'user_id' => $userId
    ], 201);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Registration failed', 'message' => $e->getMessage()], 500);
}
