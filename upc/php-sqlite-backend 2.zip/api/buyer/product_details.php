<?php
require_once '../../config.php';

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Get product ID or slug
$productId = isset($_GET['id']) ? (int)$_GET['id'] : null;
$slug = isset($_GET['slug']) ? $_GET['slug'] : null;

if (!$productId && !$slug) {
    jsonResponse(['error' => 'Product ID or slug is required'], 400);
}

try {
    $db = getDbConnection();
    
    // Build query based on ID or slug
    if ($productId) {
        $stmt = $db->prepare('
            SELECT 
                p.id, p.name, p.slug, p.description, p.price,
                p.discount_price, p.discount_start, p.discount_end,
                p.bulk_discount_threshold, p.bulk_discount_price,
                p.first_n_buyers_threshold, p.first_n_buyers_price,
                p.is_sponsored, p.qr_code,
                s.id as store_id, s.name as store_name, s.slug as store_slug,
                s.contact_info, s.location,
                c.id as category_id, c.name as category_name,
                b.business_name, b.contact_phone, b.contact_email
            FROM 
                products p
            JOIN 
                stores s ON p.store_id = s.id
            JOIN 
                businesses b ON s.business_id = b.id
            LEFT JOIN 
                categories c ON p.category_id = c.id
            WHERE 
                p.id = :id
        ');
        $stmt->bindValue(':id', $productId, SQLITE3_INTEGER);
    } else {
        $stmt = $db->prepare('
            SELECT 
                p.id, p.name, p.slug, p.description, p.price,
                p.discount_price, p.discount_start, p.discount_end,
                p.bulk_discount_threshold, p.bulk_discount_price,
                p.first_n_buyers_threshold, p.first_n_buyers_price,
                p.is_sponsored, p.qr_code,
                s.id as store_id, s.name as store_name, s.slug as store_slug,
                s.contact_info, s.location,
                c.id as category_id, c.name as category_name,
                b.business_name, b.contact_phone, b.contact_email
            FROM 
                products p
            JOIN 
                stores s ON p.store_id = s.id
            JOIN 
                businesses b ON s.business_id = b.id
            LEFT JOIN 
                categories c ON p.category_id = c.id
            WHERE 
                p.slug = :slug
        ');
        $stmt->bindValue(':slug', $slug, SQLITE3_TEXT);
    }
    
    $result = $stmt->execute();
    $product = $result->fetchArray(SQLITE3_ASSOC);
    
    if (!$product) {
        jsonResponse(['error' => 'Product not found'], 404);
    }
    
    // Get product images
    $imageStmt = $db->prepare('
        SELECT id, image_path, is_primary
        FROM product_images
        WHERE product_id = :product_id
        ORDER BY is_primary DESC, id ASC
    ');
    
    $imageStmt->bindValue(':product_id', $product['id'], SQLITE3_INTEGER);
    $imageResult = $imageStmt->execute();
    
    $images = [];
    while ($image = $imageResult->fetchArray(SQLITE3_ASSOC)) {
        $images[] = $image;
    }
    
    // Track product view for analytics
    $userId = getCurrentUserId();
    if ($userId) {
        $analyticsStmt = $db->prepare('
            INSERT INTO analytics_events (event_type, store_id, product_id, user_id, ip_address, user_agent)
            VALUES (:event_type, :store_id, :product_id, :user_id, :ip_address, :user_agent)
        ');
        
        $analyticsStmt->bindValue(':event_type', 'product_view', SQLITE3_TEXT);
        $analyticsStmt->bindValue(':store_id', $product['store_id'], SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':product_id', $product['id'], SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':user_id', $userId, SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':ip_address', $_SERVER['REMOTE_ADDR'], SQLITE3_TEXT);
        $analyticsStmt->bindValue(':user_agent', $_SERVER['HTTP_USER_AGENT'], SQLITE3_TEXT);
        
        $analyticsStmt->execute();
    }
    
    // Add images to product data
    $product['images'] = $images;
    
    jsonResponse([
        'success' => true,
        'product' => $product
    ]);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to get product details', 'message' => $e->getMessage()], 500);
}
