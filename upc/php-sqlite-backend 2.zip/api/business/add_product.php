<?php
require_once '../../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Check if user is authenticated and is a business
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'business') {
    jsonResponse(['error' => 'Unauthorized'], 401);
}

// Get form data (multipart/form-data for file uploads)
$data = $_POST;

// Validate required fields
$requiredFields = ['store_id', 'name', 'price'];
$missingFields = validateRequiredFields($data, $requiredFields);

if (!empty($missingFields)) {
    jsonResponse(['error' => 'Missing required fields', 'fields' => $missingFields], 400);
}

try {
    $db = getDbConnection();
    
    // Check if store belongs to the business
    $stmt = $db->prepare('
        SELECT s.id FROM stores s
        JOIN businesses b ON s.business_id = b.id
        WHERE s.id = :store_id AND b.user_id = :user_id
    ');
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if (!$result->fetchArray()) {
        jsonResponse(['error' => 'Store not found or access denied'], 403);
    }
    
    // Generate slug from product name
    $slug = generateSlug($data['name']);
    
    // Insert product
    $stmt = $db->prepare('
        INSERT INTO products (
            store_id, category_id, name, slug, description, price,
            discount_price, discount_start, discount_end,
            bulk_discount_threshold, bulk_discount_price,
            first_n_buyers_threshold, first_n_buyers_price
        )
        VALUES (
            :store_id, :category_id, :name, :slug, :description, :price,
            :discount_price, :discount_start, :discount_end,
            :bulk_discount_threshold, :bulk_discount_price,
            :first_n_buyers_threshold, :first_n_buyers_price
        )
    ');
    
    $stmt->bindValue(':store_id', $data['store_id'], SQLITE3_INTEGER);
    $stmt->bindValue(':category_id', $data['category_id'] ?? null, SQLITE3_INTEGER);
    $stmt->bindValue(':name', $data['name'], SQLITE3_TEXT);
    $stmt->bindValue(':slug', $slug, SQLITE3_TEXT);
    $stmt->bindValue(':description', $data['description'] ?? '', SQLITE3_TEXT);
    $stmt->bindValue(':price', $data['price'], SQLITE3_FLOAT);
    $stmt->bindValue(':discount_price', $data['discount_price'] ?? null, SQLITE3_FLOAT);
    $stmt->bindValue(':discount_start', $data['discount_start'] ?? null, SQLITE3_TEXT);
    $stmt->bindValue(':discount_end', $data['discount_end'] ?? null, SQLITE3_TEXT);
    $stmt->bindValue(':bulk_discount_threshold', $data['bulk_discount_threshold'] ?? null, SQLITE3_INTEGER);
    $stmt->bindValue(':bulk_discount_price', $data['bulk_discount_price'] ?? null, SQLITE3_FLOAT);
    $stmt->bindValue(':first_n_buyers_threshold', $data['first_n_buyers_threshold'] ?? null, SQLITE3_INTEGER);
    $stmt->bindValue(':first_n_buyers_price', $data['first_n_buyers_price'] ?? null, SQLITE3_FLOAT);
    
    $stmt->execute();
    $productId = $db->lastInsertRowID();
    
    // Handle product images
    $images = [];
    if (isset($_FILES['images']) && is_array($_FILES['images']['name'])) {
        $fileCount = count($_FILES['images']['name']);
        
        for ($i = 0; $i < $fileCount; $i++) {
            if ($_FILES['images']['error'][$i] === UPLOAD_ERR_OK) {
                $file = [
                    'name' => $_FILES['images']['name'][$i],
                    'type' => $_FILES['images']['type'][$i],
                    'tmp_name' => $_FILES['images']['tmp_name'][$i],
                    'error' => $_FILES['images']['error'][$i],
                    'size' => $_FILES['images']['size'][$i]
                ];
                
                $filename = handleFileUpload($file, PRODUCT_IMAGES_DIR);
                
                if ($filename) {
                    // Insert image record
                    $stmt = $db->prepare('
                        INSERT INTO product_images (product_id, image_path, is_primary)
                        VALUES (:product_id, :image_path, :is_primary)
                    ');
                    
                    $stmt->bindValue(':product_id', $productId, SQLITE3_INTEGER);
                    $stmt->bindValue(':image_path', $filename, SQLITE3_TEXT);
                    $stmt->bindValue(':is_primary', $i === 0 ? 1 : 0, SQLITE3_INTEGER); // First image is primary
                    
                    $stmt->execute();
                    $images[] = $filename;
                }
            }
        }
    }
    
    // Generate QR code for product
    $qrData = json_encode(['type' => 'product', 'id' => $productId, 'slug' => $slug]);
    $qrFilename = 'product-' . $productId . '.png';
    generateQRCode($qrData, $qrFilename);
    
    // Update product with QR code
    $stmt = $db->prepare('UPDATE products SET qr_code = :qr_code WHERE id = :id');
    $stmt->bindValue(':qr_code', $qrFilename, SQLITE3_TEXT);
    $stmt->bindValue(':id', $productId, SQLITE3_INTEGER);
    $stmt->execute();
    
    jsonResponse([
        'success' => true,
        'message' => 'Product added successfully',
        'product_id' => $productId,
        'slug' => $slug,
        'images' => $images,
        'qr_code' => $qrFilename
    ], 201);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to add product', 'message' => $e->getMessage()], 500);
}
