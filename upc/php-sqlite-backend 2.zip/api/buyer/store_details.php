<?php
require_once '../../config.php';

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Get store ID or slug
$storeId = isset($_GET['id']) ? (int)$_GET['id'] : null;
$slug = isset($_GET['slug']) ? $_GET['slug'] : null;

if (!$storeId && !$slug) {
    jsonResponse(['error' => 'Store ID or slug is required'], 400);
}

try {
    $db = getDbConnection();
    
    // Build query based on ID or slug
    if ($storeId) {
        $stmt = $db->prepare('
            SELECT 
                s.id, s.name, s.slug, s.description, s.logo, s.banner,
                s.location, s.latitude, s.longitude, s.contact_info, s.is_open,
                b.business_name, b.is_verified,
                (SELECT COUNT(*) FROM reviews r WHERE r.store_id = s.id) AS review_count,
                (SELECT AVG(rating) FROM reviews r WHERE r.store_id = s.id) AS avg_rating
            FROM 
                stores s
            JOIN 
                businesses b ON s.business_id = b.id
            WHERE 
                s.id = :id
        ');
        $stmt->bindValue(':id', $storeId, SQLITE3_INTEGER);
    } else {
        $stmt = $db->prepare('
            SELECT 
                s.id, s.name, s.slug, s.description, s.logo, s.banner,
                s.location, s.latitude, s.longitude, s.contact_info, s.is_open,
                b.business_name, b.is_verified,
                (SELECT COUNT(*) FROM reviews r WHERE r.store_id = s.id) AS review_count,
                (SELECT AVG(rating) FROM reviews r WHERE r.store_id = s.id) AS avg_rating
            FROM 
                stores s
            JOIN 
                businesses b ON s.business_id = b.id
            WHERE 
                s.slug = :slug
        ');
        $stmt->bindValue(':slug', $slug, SQLITE3_TEXT);
    }
    
    $result = $stmt->execute();
    $store = $result->fetchArray(SQLITE3_ASSOC);
    
    if (!$store) {
        jsonResponse(['error' => 'Store not found'], 404);
    }
    
    // Get store statuses
    $statusStmt = $db->prepare('
        SELECT id, content, image, expires_at, created_at
        FROM store_statuses
        WHERE store_id = :store_id AND expires_at > CURRENT_TIMESTAMP
        ORDER BY created_at DESC
    ');
    
    $statusStmt->bindValue(':store_id', $store['id'], SQLITE3_INTEGER);
    $statusResult = $statusStmt->execute();
    
    $statuses = [];
    while ($status = $statusResult->fetchArray(SQLITE3_ASSOC)) {
        $statuses[] = $status;
    }
    
    // Get store reviews
    $reviewStmt = $db->prepare('
        SELECT 
            r.id, r.rating, r.comment, r.created_at,
            u.name as user_name
        FROM 
            reviews r
        JOIN 
            users u ON r.user_id = u.id
        WHERE 
            r.store_id = :store_id
        ORDER BY 
            r.created_at DESC
        LIMIT 10
    ');
    
    $reviewStmt->bindValue(':store_id', $store['id'], SQLITE3_INTEGER);
    $reviewResult = $reviewStmt->execute();
    
    $reviews = [];
    while ($review = $reviewResult->fetchArray(SQLITE3_ASSOC)) {
        $reviews[] = $review;
    }
    
    // Track store view for analytics
    $userId = getCurrentUserId();
    if ($userId) {
        $analyticsStmt = $db->prepare('
            INSERT INTO analytics_events (event_type, store_id, user_id, ip_address, user_agent)
            VALUES (:event_type, :store_id, :user_id, :ip_address, :user_agent)
        ');
        
        $analyticsStmt->bindValue(':event_type', 'store_view', SQLITE3_TEXT);
        $analyticsStmt->bindValue(':store_id', $store['id'], SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':user_id', $userId, SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':ip_address', $_SERVER['REMOTE_ADDR'], SQLITE3_TEXT);
        $analyticsStmt->bindValue(':user_agent', $_SERVER['HTTP_USER_AGENT'], SQLITE3_TEXT);
        
        $analyticsStmt->execute();
    }
    
    // Add statuses and reviews to store data
    $store['statuses'] = $statuses;
    $store['reviews'] = $reviews;
    
    jsonResponse([
        'success' => true,
        'store' => $store
    ]);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to get store details', 'message' => $e->getMessage()], 500);
}
