<?php
require_once '../../config.php';

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Check if user is authenticated and is a business
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'business') {
    jsonResponse(['error' => 'Unauthorized'], 401);
}

// Get query parameters
$storeId = isset($_GET['store_id']) ? (int)$_GET['store_id'] : null;
$period = isset($_GET['period']) ? $_GET['period'] : 'week'; // day, week, month, year
$eventType = isset($_GET['event_type']) ? $_GET['event_type'] : null;

if (!$storeId) {
    jsonResponse(['error' => 'Store ID is required'], 400);
}

try {
    $db = getDbConnection();
    
    // Check if store belongs to the business
    $stmt = $db->prepare('
        SELECT s.id FROM stores s
        JOIN businesses b ON s.business_id = b.id
        WHERE s.id = :store_id AND b.user_id = :user_id
    ');
    
    $stmt->bindValue(':store_id', $storeId, SQLITE3_INTEGER);
    $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
    $result = $stmt->execute();
    
    if (!$result->fetchArray()) {
        jsonResponse(['error' => 'Store not found or access denied'], 403);
    }
    
    // Determine date range based on period
    $dateFormat = '%Y-%m-%d';
    switch ($period) {
        case 'day':
            $groupBy = "strftime('$dateFormat %H:00:00', created_at)";
            $dateRange = "datetime('now', '-1 day')";
            break;
        case 'week':
            $groupBy = "strftime('$dateFormat', created_at)";
            $dateRange = "datetime('now', '-7 days')";
            break;
        case 'month':
            $groupBy = "strftime('$dateFormat', created_at)";
            $dateRange = "datetime('now', '-30 days')";
            break;
        case 'year':
            $groupBy = "strftime('%Y-%m', created_at)";
            $dateRange = "datetime('now', '-365 days')";
            break;
        default:
            $groupBy = "strftime('$dateFormat', created_at)";
            $dateRange = "datetime('now', '-7 days')";
    }
    
    // Build query based on event type
    $eventTypeCondition = '';
    if ($eventType) {
        $eventTypeCondition = "AND event_type = :event_type";
    }
    
    // Get analytics data
    $query = "
        SELECT 
            $groupBy AS date,
            event_type,
            COUNT(*) AS count
        FROM 
            analytics_events
        WHERE 
            store_id = :store_id
            AND created_at >= $dateRange
            $eventTypeCondition
        GROUP BY 
            date, event_type
        ORDER BY 
            date ASC
    ";
    
    $stmt = $db->prepare($query);
    $stmt->bindValue(':store_id', $storeId, SQLITE3_INTEGER);
    
    if ($eventType) {
        $stmt->bindValue(':event_type', $eventType, SQLITE3_TEXT);
    }
    
    $result = $stmt->execute();
    
    $analytics = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $analytics[] = $row;
    }
    
    // Get summary statistics
    $query = "
        SELECT 
            event_type,
            COUNT(*) AS total
        FROM 
            analytics_events
        WHERE 
            store_id = :store_id
            AND created_at >= $dateRange
            $eventTypeCondition
        GROUP BY 
            event_type
    ";
    
    $stmt = $db->prepare($query);
    $stmt->bindValue(':store_id', $storeId, SQLITE3_INTEGER);
    
    if ($eventType) {
        $stmt->bindValue(':event_type', $eventType, SQLITE3_TEXT);
    }
    
    $result = $stmt->execute();
    
    $summary = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $summary[$row['event_type']] = $row['total'];
    }
    
    jsonResponse([
        'success' => true,
        'period' => $period,
        'data' => $analytics,
        'summary' => $summary
    ]);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to get analytics', 'message' => $e->getMessage()], 500);
}
