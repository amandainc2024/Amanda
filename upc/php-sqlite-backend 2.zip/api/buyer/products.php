<?php
require_once '../../config.php';

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Get query parameters
$storeId = isset($_GET['store_id']) ? (int)$_GET['store_id'] : null;
$search = isset($_GET['search']) ? $_GET['search'] : null;
$category = isset($_GET['category']) ? (int)$_GET['category'] : null;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
$sponsored = isset($_GET['sponsored']) ? (bool)$_GET['sponsored'] : false;

// Build query conditions
$conditions = [];
$params = [];

if ($storeId) {
    $conditions[] = "p.store_id = :store_id";
    $params[':store_id'] = [$storeId, SQLITE3_INTEGER];
}

if ($search) {
    $conditions[] = "(p.name LIKE :search OR p.description LIKE :search)";
    $params[':search'] = ['%' . $search . '%', SQLITE3_TEXT];
}

if ($category) {
    $conditions[] = "p.category_id = :category";
    $params[':category'] = [$category, SQLITE3_INTEGER];
}

if ($sponsored) {
    $conditions[] = "p.is_sponsored = 1 AND p.sponsored_until > CURRENT_TIMESTAMP";
}

// Build the WHERE clause
$whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

try {
    $db = getDbConnection();
    
    // Get products
    $query = "
        SELECT 
            p.id, p.name, p.slug, p.description, p.price,
            p.discount_price, p.discount_start, p.discount_end,
            p.bulk_discount_threshold, p.bulk_discount_price,
            p.first_n_buyers_threshold, p.first_n_buyers_price,
            p.is_sponsored, p.qr_code,
            s.id as store_id, s.name as store_name, s.slug as store_slug,
            c.id as category_id, c.name as category_name,
            (SELECT image_path FROM product_images pi WHERE pi.product_id = p.id AND pi.is_primary = 1 LIMIT 1) as primary_image
        FROM 
            products p
        JOIN 
            stores s ON p.store_id = s.id
        LEFT JOIN 
            categories c ON p.category_id = c.id
        $whereClause
        ORDER BY 
            p.is_sponsored DESC, p.created_at DESC
        LIMIT :limit OFFSET :offset
    ";
    
    $stmt = $db->prepare($query);
    
    // Bind parameters
    foreach ($params as $param => $value) {
        $stmt->bindValue($param, $value[0], $value[1]);
    }
    
    $stmt->bindValue(':limit', $limit, SQLITE3_INTEGER);
    $stmt->bindValue(':offset', $offset, SQLITE3_INTEGER);
    
    $result = $stmt->execute();
    
    $products = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        // Track product view for analytics
        $userId = getCurrentUserId();
        if ($userId) {
            $analyticsStmt = $db->prepare('
                INSERT INTO analytics_events (event_type, store_id, product_id, user_id, ip_address, user_agent)
                VALUES (:event_type, :store_id, :product_id, :user_id, :ip_address, :user_agent)
            ');
            
            $analyticsStmt->bindValue(':event_type', 'product_view', SQLITE3_TEXT);
            $analyticsStmt->bindValue(':store_id', $row['store_id'], SQLITE3_INTEGER);
            $analyticsStmt->bindValue(':product_id', $row['id'], SQLITE3_INTEGER);
            $analyticsStmt->bindValue(':user_id', $userId, SQLITE3_INTEGER);
            $analyticsStmt->bindValue(':ip_address', $_SERVER['REMOTE_ADDR'], SQLITE3_TEXT);
            $analyticsStmt->bindValue(':user_agent', $_SERVER['HTTP_USER_AGENT'], SQLITE3_TEXT);
            
            $analyticsStmt->execute();
        }
        
        $products[] = $row;
    }
    
    // Get total count for pagination
    $countQuery = "
        SELECT COUNT(*) as total
        FROM products p
        JOIN stores s ON p.store_id = s.id
        LEFT JOIN categories c ON p.category_id = c.id
        $whereClause
    ";
    
    $countStmt = $db->prepare($countQuery);
    
    // Bind parameters for count query
    foreach ($params as $param => $value) {
        $countStmt->bindValue($param, $value[0], $value[1]);
    }
    
    $countResult = $countStmt->execute();
    $totalCount = $countResult->fetchArray(SQLITE3_ASSOC)['total'];
    
    jsonResponse([
        'success' => true,
        'products' => $products,
        'total' => $totalCount,
        'limit' => $limit,
        'offset' => $offset
    ]);
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to get products', 'message' => $e->getMessage()], 500);
}
