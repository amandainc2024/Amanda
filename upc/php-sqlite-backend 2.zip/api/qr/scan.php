<?php
require_once '../../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$requiredFields = ['qr_data'];
$missingFields = validateRequiredFields($data, $requiredFields);

if (!empty($missingFields)) {
    jsonResponse(['error' => 'Missing required fields', 'fields' => $missingFields], 400);
}

try {
    $db = getDbConnection();
    
    // Parse QR data (should be JSON)
    $qrData = json_decode($data['qr_data'], true);
    
    if (!$qrData || !isset($qrData['type']) || !isset($qrData['id'])) {
        jsonResponse(['error' => 'Invalid QR code data'], 400);
    }
    
    $type = $qrData['type'];
    $id = $qrData['id'];
    
    // Track QR scan for analytics
    $userId = getCurrentUserId();
    if ($userId) {
        $analyticsStmt = $db->prepare('
            INSERT INTO analytics_events (event_type, store_id, product_id, user_id, ip_address, user_agent)
            VALUES (:event_type, :store_id, :product_id, :user_id, :ip_address, :user_agent)
        ');
        
        $analyticsStmt->bindValue(':event_type', 'qr_scan', SQLITE3_TEXT);
        $analyticsStmt->bindValue(':store_id', $type === 'store' ? $id : null, SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':product_id', $type === 'product' ? $id : null, SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':user_id', $userId, SQLITE3_INTEGER);
        $analyticsStmt->bindValue(':ip_address', $_SERVER['REMOTE_ADDR'], SQLITE3_TEXT);
        $analyticsStmt->bindValue(':user_agent', $_SERVER['HTTP_USER_AGENT'], SQLITE3_TEXT);
        
        $analyticsStmt->execute();
    }
    
    // Handle different QR code types
    if ($type === 'store') {
        // Get store details
        $stmt = $db->prepare('
            SELECT 
                s.id, s.name, s.slug, s.description, s.logo,
                b.business_name
            FROM 
                stores s
            JOIN 
                businesses b ON s.business_id = b.id
            WHERE 
                s.id = :id
        ');
        
        $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
        $result = $stmt->execute();
        
        $store = $result->fetchArray(SQLITE3_ASSOC);
        
        if (!$store) {
            jsonResponse(['error' => 'Store not found'], 404);
        }
        
        jsonResponse([
            'success' => true,
            'type' => 'store',
            'data' => $store,
            'redirect_url' => "/store/{$store['slug']}"
        ]);
        
    } elseif ($type === 'product') {
        // Get product details
        $stmt = $db->prepare('
            SELECT 
                p.id, p.name, p.slug, p.description, p.price,
                s.id as store_id, s.name as store_name, s.slug as store_slug,
                b.business_name
            FROM 
                products p
            JOIN 
                stores s ON p.store_id = s.id
            JOIN 
                businesses b ON s.business_id = b.id
            WHERE 
                p.id = :id
        ');
        
        $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
        $result = $stmt->execute();
        
        $product = $result->fetchArray(SQLITE3_ASSOC);
        
        if (!$product) {
            jsonResponse(['error' => 'Product not found'], 404);
        }
        
        jsonResponse([
            'success' => true,
            'type' => 'product',
            'data' => $product,
            'redirect_url' => "/product/{$product['slug']}"
        ]);
        
    } else {
        jsonResponse(['error' => 'Unknown QR code type'], 400);
    }
    
} catch (Exception $e) {
    jsonResponse(['error' => 'Failed to process QR code', 'message' => $e->getMessage()], 500);
}
